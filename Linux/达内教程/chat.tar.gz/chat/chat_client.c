#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

int sockfd;//�ͻ���socket
char name[30];

void init(){
	sockfd=socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(12345);
	addr.sin_addr.s_addr=inet_addr("127.0.0.1");
	if(connect(sockfd,(struct sockaddr*)&addr, sizeof(addr))==-1)
		perror("connect error:"),exit(-1);
}
void* recv_thread(void* p){
	while(1){
		char buf[100] = {};
		if(recv(sockfd, buf, sizeof(buf),0) == 0)
			printf("server is shutdown!\n"),exit(0);
		printf("\r%s\n%s:",buf,name);
		fflush(stdout);
	}
}
void start(){
	printf("Your Name:");
	scanf("%s", name);
	pthread_t id;
	pthread_create(&id,0,recv_thread,0);
	char buf[100] = {};
	char msg[100] = {};
	sprintf(buf,"Welcome [%s]!",name);
	send(sockfd,buf,strlen(buf),0);
	while(1){
		memset(buf,0,sizeof(buf));
		memset(msg,0,sizeof(msg));
		printf("%s:",name);
		fflush(stdout);
		scanf("%s", buf);
		sprintf(msg,"%s:%s",name,buf);
		send(sockfd, msg, strlen(msg), 0);
	}
}
int main(){
	init();
	start();
}


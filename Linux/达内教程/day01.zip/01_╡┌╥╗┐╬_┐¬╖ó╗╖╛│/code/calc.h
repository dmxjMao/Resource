#ifndef _CALC_H
#define _CALC_H

double add (double, double);

#endif // _CALC_H

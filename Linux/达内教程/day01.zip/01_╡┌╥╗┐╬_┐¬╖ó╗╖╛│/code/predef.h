#ifndef _PREDEF_H
#define _PREDEF_H

#include "print.h"

#endif // _PREDEF_H

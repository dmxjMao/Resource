#include <stdio.h>
#include "show.h"

void show (int a, char op, int b, int c) {
	printf ("%d %c %d = %d\n", a, op, b, c);
}

#ifndef _MATH_H
#define _MATH_H

#include "calc.h"
#include "show.h"

#endif // _MATH_H

#include "dao.h"
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>
const char* ID_FILE = "id.dat";
//生成一个不重复的帐号
int generator_id()
{
	static int id = 100000;
	if(access(ID_FILE,F_OK) == -1){
		int fd = open(ID_FILE,O_WRONLY|O_CREAT,0600);
		write(fd,&id,sizeof(id));
		close(fd);
		return id;
	}
	int fd = open(ID_FILE,O_RDWR);
	read(fd,&id,sizeof(id));
	id++;
	lseek(fd,0,SEEK_SET);
	write(fd,&id,sizeof(id));
	close(fd);
	return id;
}
//将一个新的帐号保存到文件
int creatUser(struct Account acc)
{
	char filename[20] = {0};
	sprintf(filename,"%d.dat",acc.id);
	int fd = open(filename,O_WRONLY|O_CREAT|O_EXCL,0600);
	if(fd == -1)
		return -1;
	if(write(fd,&acc,sizeof(acc)) < 0)
		return -1;
	close(fd);
	return 0;
}
//查找帐号，并进行销户
int destoryUser(struct Account acc)
{
	char filename[20] = {0};
	sprintf(filename,"%d.dat",acc.id);
	if(access(filename,F_OK) == -1)
		return -1;
	remove(filename);
	return 0;
}
//查找帐户，并进行存钱
int saveMoney(struct Account acc,struct Account *p)
{
	char filename[20] = {0};
	sprintf(filename,"%d.dat",acc.id);
	int fd = open(filename,O_RDWR);
	if(fd == -1)
		return -1;
	struct Account accTemp;
	read(fd,&accTemp,sizeof(accTemp));
	accTemp.balance += acc.balance;
	*p = accTemp;
	lseek(fd,-sizeof(accTemp),SEEK_CUR);
	write(fd,&accTemp,sizeof(accTemp));
	return 0;
}
//取钱的处理
int takeMoney(struct Account acc,struct Account *p)
{
	char filename[20] = {0};
	sprintf(filename,"%d.dat",acc.id);
	int fd = open(filename,O_RDWR);
	if(fd == -1)
		return -1;
	struct Account accTemp;
	read(fd,&accTemp,sizeof(accTemp));
	if(accTemp.balance < acc.balance)
		return -1;
	accTemp.balance -= acc.balance;
	*p = accTemp;
	lseek(fd,-sizeof(accTemp),SEEK_CUR);
	write(fd,&accTemp,sizeof(accTemp));
	return 0;
}
//查询余额
int queryMoney(struct Account acc,struct Account *p)
{
	char filename[20] = {0};
	sprintf(filename,"%d.dat",acc.id);
	int fd = open(filename,O_RDONLY);
	if(fd == -1)
		return -1;
	struct Account accTemp;
	read(fd,&accTemp,sizeof(accTemp));
	*p = accTemp;
	return 0;
}
//转帐的函数实现
int transfMoney(struct Account acc1,struct Account acc2,struct Account *p){
	char filename1[20] = {0};
	char filename2[20] = {0};
	sprintf(filename1,"%d.dat",acc1.id);
	sprintf(filename2,"%d.dat",acc2.id);
	int fd1 = open(filename1,O_RDWR);
	int fd2 = open(filename2,O_RDWR);
	if(fd1 == -1 || fd2 == -1)
		return -1;
	struct Account accTmp1,accTmp2;
	read(fd1,&accTmp1,sizeof(accTmp1));
	read(fd2,&accTmp2,sizeof(accTmp2));
	if(accTmp1.balance < acc1.balance)
		return -1;
	accTmp1.balance -= acc1.balance;
	accTmp2.balance += acc1.balance;
	*p = accTmp1;
	lseek(fd1,0,SEEK_SET);
	lseek(fd2,0,SEEK_SET);
	write(fd1,&accTmp1,sizeof(accTmp1));
	write(fd2,&accTmp2,sizeof(accTmp2));
	return 0;
}

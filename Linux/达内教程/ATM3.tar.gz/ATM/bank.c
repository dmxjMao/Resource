
const int key1 = 0x12345678;
const int key2 = 0x23456789;


//业务子系统
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "bank.h"
#include "dao.h"
int main()
{
	int msgid1 = msgget(key1,0);
	if(msgid1 == -1)
		perror("获取消息队列一失败"),exit(-1);
	int msgid2 = msgget(key2,0);
	if(msgid2 == -1)
		perror("获取消息队列二失败"),exit(-1);
	//开始接收消息
	while(1){
		struct Msg msg;
		struct Account accResult;
		if(msgrcv(msgid1,&msg,sizeof(msg.acc),0,0) <= 0)
			 continue;
		if(msg.mtype == M_OPEN){
		   int id = generator_id();
		   msg.acc.id = id;
		   if(creatUser(msg.acc) == -1)
			    msg.mtype = M_FAILED;
		   else
			   msg.mtype = M_SUCESS;
		   msgsnd(msgid2,&msg,sizeof(msg.acc),0);
		}
		else if(msg.mtype == M_DESTROY)
		{
			 if(destoryUser(msg.acc) == -1)
				 msg.mtype = M_FAILED;
			 else
				 msg.mtype = M_SUCESS;
			 msgsnd(msgid2,&msg,sizeof(msg.acc),0);
		}
		else if(msg.mtype == M_SAVE)
		{
			if(saveMoney(msg.acc, &accResult) == -1)
				msg.mtype = M_FAILED;
			else{
				msg.mtype = M_SUCESS;
				msg.acc.balance = accResult.balance;
			}
			msgsnd(msgid2,&msg,sizeof(msg.acc),0);
		}
		else if(msg.mtype == M_TAKE)
		{
			 if(takeMoney(msg.acc,&accResult) == -1)
				  msg.mtype = M_FAILED;
			else{
				msg.mtype = M_SUCESS;
				msg.acc.balance = accResult.balance;
			}
			msgsnd(msgid2,&msg,sizeof(msg.acc),0);
		}
		else if(msg.mtype == M_QUERY)
		{
			 if(queryMoney(msg.acc,&accResult) == -1)
				  msg.mtype = M_FAILED;
			else{
				msg.mtype = M_SUCESS;
				msg.acc.balance = accResult.balance;
			}
			msgsnd(msgid2,&msg,sizeof(msg.acc),0);
		}
		else if(msg.mtype == M_TRANSF)
		{
			 //定义一个消息结构体，来接受转入帐号
			 struct Msg msgTemp;
			 msgrcv(msgid1,&msgTemp,sizeof(msgTemp.acc),0,0);
			 if(transfMoney(msg.acc,msgTemp.acc,&accResult) == -1)
				 msg.mtype = M_FAILED;
			else{
				msg.mtype = M_SUCESS;
				msg.acc.balance = accResult.balance;
			}
			msgsnd(msgid2,&msg,sizeof(msg.acc),0);
		}
	}
   return 0;
}
